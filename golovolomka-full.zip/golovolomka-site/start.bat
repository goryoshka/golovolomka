@echo off
chcp 65001 >nul
title Inside Out
cd /d "%~dp0backend"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY set "PY=python"

if not exist ".venv\Scripts\python.exe" (
    echo Создаю окружение Python...
    %PY% -m venv .venv
    if errorlevel 1 goto nopython
)

echo Устанавливаю зависимости...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 goto pipfail

echo.
echo Сайт запущен: http://127.0.0.1:8000
echo Чтобы остановить сервер, закройте это окно.
echo.
start "" cmd /c "timeout /t 3 >nul & start http://127.0.0.1:8000"
".venv\Scripts\python.exe" -m uvicorn main:app --host 127.0.0.1 --port 8000
pause
exit /b

:nopython
echo.
echo Python не найден. Установите Python 3.10 или новее с https://www.python.org/downloads/
echo При установке отметьте галочку "Add python.exe to PATH", затем запустите start.bat снова.
pause
exit /b 1

:pipfail
echo.
echo Не получилось установить зависимости. Проверьте подключение к интернету и запустите start.bat снова.
pause
exit /b 1
