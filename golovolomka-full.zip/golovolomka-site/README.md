# Inside Out

Сайт для школьников и студентов: фокус-таймер, план на день с прогрессом за неделю, советы, дыхательные практики и игра «Пупырка».

Сейчас сайт работает на хостинге Beget: http://golovolomka-projekt.bogdam2m.beget.tech

## Устройство проекта

```
first_bit/
├── index.html, time.html, tips.html, practice.html   страницы сайта
├── pop.html, pop.css, pop.js                         игра «Пупырка» (звук «Бульк»)
├── *.css, *.js, *.png                                стили, скрипты, картинки
├── config.js                                         адрес бэкенда для фронтенда
├── start.bat                                         запуск на своём компьютере (Windows)
├── backend/
│   ├── main.py                                       сервер FastAPI + база SQLite
│   └── requirements.txt                              зависимости Python
└── deploy/
    ├── setup.sh                                      установка на VPS с Ubuntu
    └── beget/                                        файлы для обычного хостинга Beget
        ├── passenger_wsgi.py                         точка входа Passenger (FastAPI через a2wsgi)
        └── .htaccess                                 включает Passenger и путь к Python
```

Бэкенд хранит задачи «Плана на день» и считает «Прогресс за неделю».
Аккаунтов нет: каждый браузер получает анонимный идентификатор, и сервер показывает ему только его задачи.

API:

| Метод  | Путь                          | Что делает                        |
|--------|-------------------------------|-----------------------------------|
| GET    | `/api/health`                 | проверка, что сервер жив          |
| GET    | `/api/tasks?date=YYYY-MM-DD`  | задачи на дату                    |
| POST   | `/api/tasks`                  | добавить задачу `{text, date}`    |
| PATCH  | `/api/tasks/{id}`             | отметить `{completed: true/false}`|
| DELETE | `/api/tasks/{id}`             | удалить задачу                    |
| GET    | `/api/stats/week?date=…`      | процент выполненных задач по дням недели |

Документация API открывается по адресу `/docs`.

## Запуск на своём компьютере

Нужен Python 3.10 или новее.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Откройте http://127.0.0.1:8000 — сервер отдаёт и сайт, и API. В `config.js` ничего менять не нужно.
База данных создастся сама в файле `backend/inside_out.db`.

## Публикация в интернете

GitHub Pages умеет показывать только HTML/CSS/JS и не запускает Python. Есть два варианта.

**1. Всё на одном хостинге (проще).** Разместите весь репозиторий на сервисе, который запускает Python (Render, Railway, PythonAnywhere и т. п.):
- папка запуска: `backend`
- установка: `pip install -r requirements.txt`
- запуск: `uvicorn main:app --host 0.0.0.0 --port $PORT`

Сайт и API будут по одному адресу, `config.js` не трогаем.

**2. Сайт на GitHub Pages, бэкенд отдельно.**
1. Разместите бэкенд, как в варианте 1, и добавьте переменную окружения
   `CORS_ORIGINS=https://goryoshka.github.io`
2. Впишите адрес бэкенда в `config.js`, например:
   `window.INSIDE_OUT_API_URL = "https://inside-out-api.onrender.com";`
3. Загрузите изменения в репозиторий — GitHub Pages обновится сам.

На бесплатных тарифах диск часто очищается при перезапуске, и задачи в SQLite могут пропасть. Если это важно, подключите постоянный диск или задайте путь к базе через переменную `DB_PATH`.

## Настройки сервера

| Переменная     | По умолчанию                       | Зачем                                   |
|----------------|------------------------------------|-----------------------------------------|
| `CORS_ORIGINS` | localhost:5500–5502 и 8000         | с каких адресов сайту можно ходить в API |
| `DB_PATH`      | `backend/inside_out.db`            | где лежит файл базы                      |

Папка `backend` и скрытые файлы (`.git`) сервером наружу не отдаются, так что код и база недоступны по ссылке.

## Как сайт устроен на Beget

Папка сайта на хостинге: `~/golovolomka-projekt.ru/`

```
golovolomka-projekt.ru/
├── .htaccess            из deploy/beget
├── passenger_wsgi.py    из deploy/beget
├── app/                 файлы сайта и папка backend
├── data/inside_out.db   база задач
├── venv/                Python 3.10 + fastapi, uvicorn, a2wsgi
├── public -> public_html
└── tmp/restart.txt      «touch» этого файла перезапускает сайт
```

Окружение `venv` нужно создавать внутри папки сайта: иначе у веб-сервера Beget не будет к нему доступа.

```bash
cd ~/golovolomka-projekt.ru
python3 -m venv --without-pip venv
curl -sS https://bootstrap.pypa.io/get-pip.py -o ~/gp.py && venv/bin/python ~/gp.py
venv/bin/pip install fastapi uvicorn a2wsgi
touch tmp/restart.txt
```

