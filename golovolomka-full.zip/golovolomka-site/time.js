// Тайм-менеджмент: фокус-таймер, план на день и прогресс за неделю.
// Задачи и статистика хранятся на сервере (backend/main.py, FastAPI + SQLite).
// Адрес сервера задаётся в config.js.

(function () {
    'use strict';

    // ---------- Связь с сервером ----------
    var API_URL = (window.INSIDE_OUT_API_URL || '').replace(/\/+$/, '');

    // Анонимный идентификатор браузера: по нему сервер отличает задачи разных людей.
    function makeId() {
        if (window.crypto && crypto.randomUUID) return crypto.randomUUID();
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0;
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
    }

    var clientId = null;
    try { clientId = localStorage.getItem('client_id'); } catch (e) { /* хранилище недоступно */ }
    if (!clientId) {
        clientId = makeId();
        try { localStorage.setItem('client_id', clientId); } catch (e) { /* без сохранения id */ }
    }

    function api(path, options) {
        options = options || {};
        var headers = { 'X-Client-ID': clientId };
        if (options.body) headers['Content-Type'] = 'application/json';

        return fetch(API_URL + path, {
            method: options.method || 'GET',
            headers: headers,
            body: options.body ? JSON.stringify(options.body) : undefined
        }).catch(function () {
            throw new Error('Не удалось связаться с сервером. Проверьте, что бэкенд запущен.');
        }).then(function (res) {
            if (res.status === 204) return null;
            return res.json().catch(function () { return {}; }).then(function (data) {
                if (!res.ok) {
                    var detail = typeof data.detail === 'string' ? data.detail : 'Ошибка в данных запроса';
                    throw new Error(detail + ' (код ' + res.status + ')');
                }
                return data;
            });
        });
    }

    // ---------- Даты ----------
    function toKey(date) {
        var m = String(date.getMonth() + 1).padStart(2, '0');
        var d = String(date.getDate()).padStart(2, '0');
        return date.getFullYear() + '-' + m + '-' + d;
    }

    function fromKey(key) {
        var parts = key.split('-').map(Number);
        return new Date(parts[0], parts[1] - 1, parts[2]);
    }

    function shortDate(key) {
        var parts = key.split('-');
        return parts[2] + '.' + parts[1];
    }

    // ---------- Фокус-таймер ----------
    var WORK = 30 * 60;
    var BREAK = 5 * 60;

    var timerEl = document.getElementById('tt');
    var modeEl = document.getElementById('tm');
    var toggleBtn = document.getElementById('tg');
    var resetBtn = document.getElementById('tr');

    var mode = 'work';
    var remaining = WORK;
    var endsAt = null;
    var tickId = null;
    var baseTitle = document.title;

    function format(sec) {
        var m = Math.floor(sec / 60);
        var s = sec % 60;
        return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
    }

    function renderTimer() {
        timerEl.textContent = format(remaining);
        modeEl.textContent = mode === 'work' ? 'Работа' : 'Отдых';
        toggleBtn.textContent = endsAt ? 'Пауза' : (remaining === (mode === 'work' ? WORK : BREAK) ? 'Старт' : 'Продолжить');
        document.title = endsAt ? format(remaining) + ' · ' + (mode === 'work' ? 'Работа' : 'Отдых') : baseTitle;
    }

    function beep() {
        try {
            var Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return;
            var ctx = new Ctx();
            var osc = ctx.createOscillator();
            var gain = ctx.createGain();
            osc.frequency.value = 660;
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 1);
        } catch (e) { /* звук необязателен */ }
    }

    function tick() {
        remaining = Math.max(0, Math.round((endsAt - Date.now()) / 1000));
        if (remaining === 0) {
            beep();
            mode = mode === 'work' ? 'break' : 'work';
            remaining = mode === 'work' ? WORK : BREAK;
            endsAt = Date.now() + remaining * 1000; // следующий отрезок стартует сам
        }
        renderTimer();
    }

    function start() {
        endsAt = Date.now() + remaining * 1000;
        tickId = setInterval(tick, 250);
        renderTimer();
    }

    function pause() {
        clearInterval(tickId);
        tickId = null;
        endsAt = null;
        renderTimer();
    }

    toggleBtn.addEventListener('click', function () {
        if (endsAt) pause(); else start();
    });

    resetBtn.addEventListener('click', function () {
        pause();
        mode = 'work';
        remaining = WORK;
        renderTimer();
    });

    renderTimer();

    // ---------- План на день ----------
    var dateInput = document.getElementById('pd');
    var form = document.getElementById('pf');
    var input = document.getElementById('pi');
    var list = document.getElementById('pl');
    var empty = document.getElementById('pe');
    var errorEl = document.getElementById('perr');
    var errorTimer = null;

    dateInput.value = toKey(new Date());

    function currentKey() {
        return dateInput.value || toKey(new Date());
    }

    function showError(err) {
        errorEl.textContent = err && err.message ? err.message : String(err);
        errorEl.hidden = false;
        clearTimeout(errorTimer);
        errorTimer = setTimeout(function () { errorEl.hidden = true; }, 6000);
    }

    function renderTasks(tasks) {
        list.innerHTML = '';

        tasks.forEach(function (task) {
            var li = document.createElement('li');
            li.className = 'task' + (task.completed ? ' done' : '');

            var label = document.createElement('label');
            var box = document.createElement('input');
            box.type = 'checkbox';
            box.checked = task.completed;
            box.addEventListener('change', function () {
                box.disabled = true;
                api('/api/tasks/' + task.id, { method: 'PATCH', body: { completed: box.checked } })
                    .then(refresh)
                    .catch(function (err) {
                        box.checked = !box.checked;
                        box.disabled = false;
                        showError(err);
                    });
            });
            var text = document.createElement('span');
            text.textContent = task.text;
            label.appendChild(box);
            label.appendChild(text);

            var del = document.createElement('button');
            del.type = 'button';
            del.className = 'task-delete';
            del.setAttribute('aria-label', 'Удалить задачу');
            del.textContent = '×';
            del.addEventListener('click', function () {
                del.disabled = true;
                api('/api/tasks/' + task.id, { method: 'DELETE' })
                    .then(refresh)
                    .catch(function (err) {
                        del.disabled = false;
                        showError(err);
                    });
            });

            li.appendChild(label);
            li.appendChild(del);
            list.appendChild(li);
        });

        empty.hidden = tasks.length > 0;
    }

    function loadTasks() {
        var key = currentKey();
        return api('/api/tasks?date=' + key).then(function (data) {
            if (key === currentKey()) renderTasks(data.tasks);
        });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var text = input.value.trim();
        if (!text) return;
        var submitBtn = form.querySelector('button[type="submit"]');
        submitBtn.disabled = true;
        api('/api/tasks', { method: 'POST', body: { text: text, date: currentKey() } })
            .then(function () {
                input.value = '';
                input.focus();
                return refresh();
            })
            .catch(showError)
            .then(function () { submitBtn.disabled = false; });
    });

    dateInput.addEventListener('change', function () {
        refresh().catch(showError);
    });

    // ---------- Прогресс за неделю ----------
    var weekEl = document.getElementById('wp');
    var rangeEl = document.getElementById('wr');

    function renderWeek(days) {
        var todayKey = toKey(new Date());
        var fmt = { day: 'numeric', month: 'long' };
        weekEl.innerHTML = '';

        if (days.length) {
            rangeEl.textContent = fromKey(days[0].date).toLocaleDateString('ru-RU', fmt) + ' — ' +
                fromKey(days[days.length - 1].date).toLocaleDateString('ru-RU', fmt);
        }

        days.forEach(function (day) {
            var col = document.createElement('button');
            col.type = 'button';
            col.className = 'day' + (day.date === todayKey ? ' today' : '') + (day.date === currentKey() ? ' selected' : '');
            col.title = fromKey(day.date).toLocaleDateString('ru-RU', fmt) + ': выполнено ' + day.done + ' из ' + day.total;

            var fill = document.createElement('div');
            fill.className = 'fill';
            fill.style.height = day.percent + '%';

            var label = document.createElement('span');
            label.className = 'label';
            label.textContent = shortDate(day.date);

            var pct = document.createElement('span');
            pct.className = 'percent';
            pct.textContent = day.total ? day.percent + '%' : '—';

            col.appendChild(fill);
            col.appendChild(label);
            col.appendChild(pct);
            col.addEventListener('click', function () {
                dateInput.value = day.date;
                refresh().catch(showError);
            });
            weekEl.appendChild(col);
        });
    }

    function loadWeek() {
        return api('/api/stats/week?date=' + currentKey()).then(function (data) {
            renderWeek(data.days);
        });
    }

    function refresh() {
        return Promise.all([loadTasks(), loadWeek()]);
    }

    // Пока сервер не ответил, показываем пустую неделю
    (function placeholderWeek() {
        var monday = fromKey(currentKey());
        monday.setDate(monday.getDate() - (monday.getDay() + 6) % 7);
        var days = [];
        for (var i = 0; i < 7; i++) {
            var d = new Date(monday);
            d.setDate(monday.getDate() + i);
            days.push({ date: toKey(d), total: 0, done: 0, percent: 0 });
        }
        renderWeek(days);
    })();

    refresh().catch(showError);
})();
