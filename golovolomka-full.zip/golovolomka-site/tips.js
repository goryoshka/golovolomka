// Советы: фильтр карточек по категориям и кнопка «Читать далее..».

(function () {
    'use strict';

    var buttons = document.querySelectorAll('[data-filter]');
    var cards = document.querySelectorAll('[data-cat]');
    var more = document.getElementById('tipsMore');
    var current = 'all';
    var expanded = false;

    function apply(filter) {
        current = filter;
        buttons.forEach(function (btn) {
            var on = btn.dataset.filter === filter;
            btn.classList.toggle('is-active', on);
            btn.setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        cards.forEach(function (card) {
            var otherCat = filter !== 'all' && card.dataset.cat !== filter;
            var folded = filter === 'all' && !expanded && card.hasAttribute('data-extra');
            card.hidden = otherCat || folded;
        });
        // Во вкладках «Психология» и «Организация учебы» видны все советы сразу
        if (more) more.hidden = filter !== 'all' || expanded;
    }

    buttons.forEach(function (btn) {
        btn.addEventListener('click', function () {
            apply(btn.dataset.filter);
        });
    });

    if (more) {
        more.addEventListener('click', function () {
            expanded = true;
            apply(current);
        });
    }

    apply('all');
})();
