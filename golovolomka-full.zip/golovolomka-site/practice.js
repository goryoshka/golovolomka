// Практики: дыхание по квадрату (4 секунды на каждую фазу).

(function () {
    'use strict';

    var PHASE_SEC = 4;
    var PHASES = [
        { name: 'Вдох', big: true },
        { name: 'Пауза', big: true },
        { name: 'Выдох', big: false },
        { name: 'Пауза', big: false }
    ];

    var circle = document.getElementById('bc');
    var phaseEl = document.getElementById('bp');
    var countEl = document.getElementById('bn');
    var button = document.getElementById('bs');
    var cyclesEl = document.getElementById('bcy');

    circle.style.transitionDuration = PHASE_SEC + 's';

    var running = false;
    var phase = 0;
    var secondsLeft = 0;
    var cycles = 0;
    var timerId = null;

    function showPhase() {
        var p = PHASES[phase];
        phaseEl.textContent = p.name;
        circle.classList.toggle('big', p.big);
    }

    function step() {
        secondsLeft--;
        if (secondsLeft === 0) {
            phase = (phase + 1) % PHASES.length;
            if (phase === 0) {
                cycles++;
                cyclesEl.textContent = 'Циклов: ' + cycles;
            }
            secondsLeft = PHASE_SEC;
            showPhase();
        }
        countEl.textContent = secondsLeft;
    }

    function start() {
        running = true;
        phase = 0;
        cycles = 0;
        secondsLeft = PHASE_SEC;
        cyclesEl.textContent = 'Циклов: 0';
        countEl.textContent = secondsLeft;
        showPhase();
        timerId = setInterval(step, 1000);
        button.textContent = 'Остановить';
    }

    function stop() {
        running = false;
        clearInterval(timerId);
        circle.classList.remove('big');
        phaseEl.textContent = cycles ? 'Хорошо!' : 'Готов?';
        countEl.textContent = '';
        button.textContent = 'Начать';
    }

    button.addEventListener('click', function () {
        if (running) stop(); else start();
    });
})();
