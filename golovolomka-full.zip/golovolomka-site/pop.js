// Пупырка: лист пузырчатой плёнки, звуки синтезируются в браузере (без аудиофайлов).

(function () {
    'use strict';

    var BUBBLES = 60;
    var STORAGE_KEY = 'insideout.popSound';

    var sheet = document.getElementById('popSheet');
    var countEl = document.getElementById('popCount');
    var sheetsEl = document.getElementById('sheetCount');
    var doneEl = document.getElementById('popDone');
    var resetBtn = document.getElementById('popReset');
    var soundBtns = document.querySelectorAll('.pop-sound');

    var popped = 0;
    var sheets = 0;
    var left = 0;
    var pressing = false;
    var refillTimer = null;

    // ---------- Звуки ----------
    var ctx = null;
    function audio() {
        if (!ctx) {
            var Ctx = window.AudioContext || window.webkitAudioContext;
            if (!Ctx) return null;
            ctx = new Ctx();
        }
        if (ctx.state === 'suspended') ctx.resume();
        return ctx;
    }

    function noiseBuffer(ac, seconds) {
        var len = Math.floor(ac.sampleRate * seconds);
        var buf = ac.createBuffer(1, len, ac.sampleRate);
        var data = buf.getChannelData(0);
        for (var i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
        return buf;
    }

    function envelope(ac, gainNode, peak, attack, decay) {
        var t = ac.currentTime;
        gainNode.gain.setValueAtTime(0.0001, t);
        gainNode.gain.exponentialRampToValueAtTime(peak, t + attack);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, t + attack + decay);
        return t + attack + decay + 0.02;
    }

    var SOUNDS = {
        // Бульк: тон, скользящий вверх
        bubble: function (ac, vary) {
            var osc = ac.createOscillator();
            osc.type = 'sine';
            var t = ac.currentTime;
            osc.frequency.setValueAtTime(260 * vary, t);
            osc.frequency.exponentialRampToValueAtTime(900 * vary, t + 0.07);
            var g = ac.createGain();
            osc.connect(g); g.connect(ac.destination);
            var end = envelope(ac, g, 0.5, 0.005, 0.09);
            osc.start(); osc.stop(end);
        },
        none: function () {}
    };

    var current = 'bubble';
    try {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved && SOUNDS[saved]) current = saved;
    } catch (e) { /* без сохранения */ }

    function play(name) {
        if (name === 'none') return;
        var ac = audio();
        if (!ac) return;
        var vary = 0.85 + Math.random() * 0.3; // каждый пузырь звучит чуть по-своему
        SOUNDS[name](ac, vary);
    }

    function selectSound(name) {
        current = name;
        soundBtns.forEach(function (b) {
            b.setAttribute('aria-checked', b.dataset.sound === name ? 'true' : 'false');
        });
        try { localStorage.setItem(STORAGE_KEY, name); } catch (e) { /* без сохранения */ }
    }

    soundBtns.forEach(function (b) {
        b.addEventListener('click', function () {
            selectSound(b.dataset.sound);
            play(b.dataset.sound); // сразу даём послушать
        });
    });
    selectSound(current);

    // ---------- Лист с пупырками ----------
    function pop(bubble) {
        if (!bubble || bubble.classList.contains('popped')) return;
        bubble.classList.add('popped');
        bubble.setAttribute('aria-label', 'Лопнутый пузырёк');
        bubble.disabled = true;
        play(current);
        if (navigator.vibrate) {
            try { navigator.vibrate(8); } catch (e) { /* не везде доступно */ }
        }
        popped++;
        left--;
        countEl.textContent = popped;
        if (left === 0) {
            doneEl.hidden = false;
            refillTimer = setTimeout(fill, 1200);
        }
    }

    function fill() {
        clearTimeout(refillTimer);
        doneEl.hidden = true;
        sheet.innerHTML = '';
        for (var i = 0; i < BUBBLES; i++) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'bubble';
            b.setAttribute('aria-label', 'Пузырёк');
            sheet.appendChild(b);
        }
        left = BUBBLES;
        sheets++;
        sheetsEl.textContent = sheets;
    }

    function bubbleAt(x, y) {
        var el = document.elementFromPoint(x, y);
        return el && el.classList && el.classList.contains('bubble') ? el : null;
    }

    sheet.addEventListener('pointerdown', function (e) {
        pressing = true;
        pop(bubbleAt(e.clientX, e.clientY));
    });
    sheet.addEventListener('pointermove', function (e) {
        if (pressing) pop(bubbleAt(e.clientX, e.clientY));
    });
    window.addEventListener('pointerup', function () { pressing = false; });
    window.addEventListener('pointercancel', function () { pressing = false; });

    // С клавиатуры: Tab до пузырька и Enter/пробел
    sheet.addEventListener('click', function (e) {
        if (e.detail === 0) pop(e.target.closest('.bubble'));
    });

    resetBtn.addEventListener('click', fill);

    fill();
})();
