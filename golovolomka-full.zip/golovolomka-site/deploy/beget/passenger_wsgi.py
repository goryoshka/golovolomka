# Точка входа для хостинга Beget (Passenger, WSGI).
# FastAPI — это ASGI-приложение, поэтому оборачиваем его через a2wsgi.
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "data")
os.makedirs(DATA_DIR, exist_ok=True)
os.environ.setdefault("DB_PATH", os.path.join(DATA_DIR, "inside_out.db"))

sys.path.insert(0, os.path.join(HERE, "app", "backend"))

from a2wsgi import ASGIMiddleware  # noqa: E402

import main  # noqa: E402

main.init_db()  # под WSGI событие lifespan не вызывается, создаём таблицы сами
application = ASGIMiddleware(main.app)
