#!/usr/bin/env bash
# Установка сайта «Головоломка» (Inside Out) на VPS с Ubuntu 22.04 / 24.04.
#
# Запуск (от root, из любой папки):
#   bash setup.sh golovolomka-projekt.ru
#
# Скрипт можно запускать повторно: так же обновляется сайт после правок.
# Что он делает:
#   1. ставит Python, nginx и certbot;
#   2. копирует сайт в /opt/golovolomka, база — /var/lib/golovolomka/inside_out.db;
#   3. запускает бэкенд как службу (сам поднимается после перезагрузки);
#   4. настраивает nginx на домен и получает бесплатный HTTPS-сертификат.

set -euo pipefail

DOMAIN="${1:-}"
APP_DIR=/opt/golovolomka
DATA_DIR=/var/lib/golovolomka
SERVICE=golovolomka
SRC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

say() { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
die() { printf '\n\033[1;31mОшибка: %s\033[0m\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "запустите скрипт от root (или через sudo)."
[ -n "$DOMAIN" ] || die "укажите домен, например: bash setup.sh golovolomka-projekt.ru"
[ -f "$SRC_DIR/backend/main.py" ] || die "не нашла backend/main.py рядом со скриптом. Распакуйте архив целиком."

say "Ставлю нужные программы"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get install -y -q python3 python3-venv python3-pip nginx certbot python3-certbot-nginx rsync curl

say "Копирую сайт в $APP_DIR"
mkdir -p "$APP_DIR" "$DATA_DIR"
rsync -a --delete \
    --exclude '.git' --exclude '.venv' --exclude '__pycache__' \
    --exclude 'backend/inside_out.db' --exclude 'start.bat' \
    "$SRC_DIR"/ "$APP_DIR"/

say "Устанавливаю зависимости Python"
if [ ! -x "$APP_DIR/.venv/bin/python" ]; then
    python3 -m venv "$APP_DIR/.venv"
fi
"$APP_DIR/.venv/bin/pip" install -q --upgrade pip
"$APP_DIR/.venv/bin/pip" install -q -r "$APP_DIR/backend/requirements.txt"

chown -R www-data:www-data "$DATA_DIR"
chmod -R a+rX "$APP_DIR"

say "Запускаю бэкенд как службу"
cat > /etc/systemd/system/$SERVICE.service <<EOF
[Unit]
Description=Golovolomka (Inside Out) FastAPI
After=network.target

[Service]
User=www-data
Group=www-data
WorkingDirectory=$APP_DIR/backend
Environment=DB_PATH=$DATA_DIR/inside_out.db
Environment=CORS_ORIGINS=https://$DOMAIN,https://www.$DOMAIN,https://goryoshka.github.io
ExecStart=$APP_DIR/.venv/bin/uvicorn main:app --host 127.0.0.1 --port 8000 --proxy-headers --forwarded-allow-ips=127.0.0.1
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable -q $SERVICE
systemctl restart $SERVICE

for i in $(seq 1 20); do
    if curl -fs http://127.0.0.1:8000/api/health >/dev/null; then break; fi
    sleep 1
done
curl -fs http://127.0.0.1:8000/api/health >/dev/null \
    || die "бэкенд не запустился. Посмотрите журнал: journalctl -u $SERVICE -n 50"

say "Настраиваю nginx для $DOMAIN"
cat > /etc/nginx/sites-available/$SERVICE <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name $DOMAIN www.$DOMAIN;

    client_max_body_size 1m;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
    }
}
EOF
ln -sf /etc/nginx/sites-available/$SERVICE /etc/nginx/sites-enabled/$SERVICE
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl reload nginx

if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
    ufw allow OpenSSH >/dev/null
    ufw allow 'Nginx Full' >/dev/null
fi

say "Получаю HTTPS-сертификат"
if certbot --nginx -n --agree-tos --register-unsafely-without-email --redirect \
        -d "$DOMAIN" -d "www.$DOMAIN"; then
    URL="https://$DOMAIN"
else
    URL="http://$DOMAIN"
    printf '\n\033[1;33mСертификат пока не выдан.\033[0m Обычно это значит, что DNS-записи домена\n'
    printf 'ещё не указывают на этот сервер. Подождите 15–60 минут и запустите скрипт снова.\n'
fi

say "Готово! Сайт: $URL"
echo "Проверка API: $URL/api/health"
echo "Журнал бэкенда: journalctl -u $SERVICE -f"
